__author__ = 'Muhammad Abdullah Mughal'
__email__ = 'iamabdullahmughal@gmail.com'
__website__ = 'https://www.iabdullahmughal.com'
__twitter__ = '@iabdullahmughal'

import unittest


class TestMethods(unittest.TestCase):
    def test_add(self):
        pass


if __name__ == '__main__':
    unittest.main()
