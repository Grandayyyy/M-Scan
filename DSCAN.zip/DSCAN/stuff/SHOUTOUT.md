# Shout Out
I have used different free to use, open source libraries, code and libraries for competition of this project. 
So following is shout out for all those. Some of them are listed below. 

## Python Libraries  
| Sr. No | Library / Code  | Repo / Site |
| ------------- |  ------------- | ------------- |
|1. | Vba2Graph  | https://github.com/MalwareCantFly/Vba2Graph  |
|2. | python-magic  | https://github.com/ahupp/python-magic |
|3. | identify  | https://github.com/chriskuehl/identify |
|4. | ssdeep  | https://github.com/ssdeep-project/ssdeep |
|5. | oletools  | https://github.com/decalage2/oletools |
|6. | virustotal-api  | https://www.virustotal.com/en/documentation/public-api/ |
|6. | yara-python  | https://github.com/VirusTotal/yara-python |


## Web Page Template
| Sr. No | Code  | Repo / Site |
| ------------- |  ------------- | ------------- |
|1. | tabler | https://github.com/tabler/tabler  |

## Javascript & CSS
| Sr. No | Code  | Repo / Site |
| ------------- |  ------------- | ------------- |
|1. | font awesome | https://fontawesome.com  |
|2. | simple line icons | https://github.com/thesabbir/simple-line-icons |
|3. | mermaid| https://github.com/knsv/mermaid |


## Image Source 
| Sr. No | Name  | Repo / Site |
| ------------- |  ------------- | ------------- |
|1. | fav.svg | https://flaticon.com  |

## Malicious Samples
| Sr. No | Vendor  | Repo / Site |
| ------------- |  ------------- | ------------- |
|1. | InQuest | https://github.com/InQuest/malware-samples  |

## Software
| Sr. No | Name  | Repo / Site |
| ------------- |  ------------- | ------------- |
|1. | pycharm | https://www.jetbrains.com/pycharm/  |
|2. | gitkraken | https://www.gitkraken.com/  |

