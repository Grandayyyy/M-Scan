
from core.analysis.identification.filesize.file_size import FileSize

__all__ = ['FileSize']
